<?php
/**
 * Solar Planner module for MajorDoMo.
 *
 * Solar generation and night battery charge planner. Multi-provider PV forecast,
 * load forecast, interval energy simulator, TargetSocAt07, Deye TOU compiler and
 * a safe shadow mode. Does NOT write to the inverter by default.
 *
 * @package    solarplanner
 * @author     mambursoft
 * @copyright  2026 mambursoft
 * @license    MIT
 * @version    1.2.1
 */

require_once(dirname(__FILE__) . '/lib/autoload.php');

use SolarPlanner\MajorDoMo\Config;

class solarplanner extends module
{
    function solarplanner()
    {
        $this->name            = 'solarplanner';
        $this->title           = 'Solar Planner';
        $this->module_category = '<#LANG_SECTION_DEVICES#>';
        $this->checkInstalled();
    }

    function __construct()
    {
        $this->solarplanner();
    }

    function saveParams($data = 0)
    {
        $p = array();
        if (isset($this->id))          $p['id']          = $this->id;
        if (isset($this->view_mode))   $p['view_mode']   = $this->view_mode;
        if (isset($this->edit_mode))   $p['edit_mode']   = $this->edit_mode;
        if (isset($this->data_source)) $p['data_source'] = $this->data_source;
        if (isset($this->tab))         $p['tab']         = $this->tab;
        return parent::saveParams($p);
    }

    function getParams()
    {
        global $id, $mode, $view_mode, $edit_mode, $data_source, $tab;
        if (isset($id))          $this->id          = $id;
        if (isset($mode))        $this->mode        = $mode;
        if (isset($view_mode))   $this->view_mode   = $view_mode;
        if (isset($edit_mode))   $this->edit_mode   = $edit_mode;
        if (isset($tab))         $this->tab         = $tab;
        if (isset($data_source)) $this->data_source = $data_source;
    }

    function run()
    {
        global $session;
        $out = array();

        if ($this->action == 'admin') {
            $this->admin($out);
        } else {
            $this->usual($out);
        }

        if (isset($this->owner->action)) {
            $out['PARENT_ACTION'] = $this->owner->action;
        }
        if (isset($this->owner->name)) {
            $out['PARENT_NAME'] = $this->owner->name;
        }

        // populateView() already selected a sensible default tab (overview for
        // configured installs, settings otherwise). Only override it when a
        // real view_mode was provided by the request.
        if (!empty($this->view_mode) || !isset($out['VIEW_MODE'])) {
            $out['VIEW_MODE'] = $this->view_mode;
        }
        $out['EDIT_MODE']   = $this->edit_mode;
        $out['MODE']        = $this->mode;
        $out['ACTION']      = $this->action;
        $out['DATA_SOURCE'] = $this->data_source;
        $out['TAB']         = $this->tab;

        $this->data = $out;

        $templateFile = DIR_TEMPLATES . $this->name . '/' . $this->name . '.html';
        if (!file_exists($templateFile) && defined('ROOT')) {
            $templateFile = ROOT . 'templates/' . $this->name . '/' . $this->name . '.html';
        }
        if (!file_exists($templateFile)) {
            $templateFile = DIR_MODULES . $this->name . '/templates/' . $this->name . '.html';
        }
        if (!file_exists($templateFile) && defined('ROOT')) {
            $templateFile = ROOT . 'modules/' . $this->name . '/templates/' . $this->name . '.html';
        }

        $p = new parser($templateFile, $this->data, $this);
        $this->result = $p->result;
    }

    function checkInstalled()
    {
        parent::checkInstalled();

        $rec = SQLSelectOne("SELECT ID, CATEGORY FROM project_modules WHERE NAME='" . $this->name . "'");
        if (!$rec['ID']) {
            $rec = array(
                'NAME'     => $this->name,
                'TITLE'    => $this->title,
                'CATEGORY' => $this->module_category,
                'DATA'     => '',
            );
            SQLInsert('project_modules', $rec);
        } elseif ($rec['CATEGORY'] != $this->module_category) {
            $rec['CATEGORY'] = $this->module_category;
            SQLUpdate('project_modules', $rec);
        }

        if (defined('ROOT') && is_dir(ROOT . 'cms/modules_installed')) {
            $flagFile = ROOT . 'cms/modules_installed/' . $this->name . '.installed';
            if (!file_exists($flagFile)) {
                @file_put_contents($flagFile, date("H:i d.m.Y"));
            }
        }

        // Provision the module icon into the web root /img/modules/ so the UI
        // header and module list can show it even if the package extractor did
        // not place it there directly.
        if (defined('ROOT')) {
            $dstDir = ROOT . 'img/modules/';
            if (!is_dir($dstDir)) {
                @mkdir($dstDir, 0775, true);
            }
            $srcIcon = DIR_MODULES . $this->name . '/../../img/modules/' . $this->name . '.png';
            $srcIconAlt = ROOT . 'modules/' . $this->name . '/img/' . $this->name . '.png';
            $dstIcon = $dstDir . $this->name . '.png';
            if (!file_exists($dstIcon)) {
                if (file_exists($srcIcon)) {
                    @copy($srcIcon, $dstIcon);
                } elseif (file_exists($srcIconAlt)) {
                    @copy($srcIconAlt, $dstIcon);
                }
            }
        }

        // Register in plugins table for Marketplace & Installed extensions.
        $hasPlugins = SQLSelectOne("SHOW TABLES LIKE 'plugins'");
        if ($hasPlugins) {
            $col = SQLSelectOne("SHOW COLUMNS FROM plugins LIKE 'MODULE_NAME'");
            $keyField = ($col && isset($col['Field'])) ? 'MODULE_NAME' : 'NAME';

            $pRec = SQLSelectOne("SELECT * FROM plugins WHERE " . $keyField . "='" . $this->name . "'");
            $descRu = 'Планировщик солнечной генерации и ночного заряда батарей: мультипровайдерный прогноз PV (Open-Meteo, Forecast.Solar, Solcast), прогноз нагрузки, интервальный симулятор, расчёт TargetSocAt07, компилятор Deye Time of Use, безопасный shadow mode. По умолчанию не пишет в инвертор.';
            $descEn = 'Solar generation and night battery charge planner: multi-provider PV forecast (Open-Meteo, Forecast.Solar, Solcast), load forecast, interval simulator, TargetSocAt07, Deye Time of Use compiler, safe shadow mode. Does not write to the inverter by default.';

            if (!$pRec['ID']) {
                $pRec = array(
                    $keyField         => $this->name,
                    'TITLE'           => $this->title,
                    'AUTHOR'          => 'mambursoft',
                    'SUPPORT_URL'     => 'https://github.com/mambursoft/majordomo-solarPlanner',
                    'REPOSITORY_URL'  => 'https://github.com/mambursoft/majordomo-solarPlanner',
                    'DESCRIPTION_RU'  => $descRu,
                    'DESCRIPTION_EN'  => $descEn,
                    'CURRENT_VERSION' => '1.2.1',
                    'LATEST_VERSION'  => '1.2.1',
                    'IS_INSTALLED'    => 1,
                    'LATEST_UPDATE'   => date('Y-m-d H:i:s'),
                );
                SQLInsert('plugins', $pRec);
            } else {
                $pRec['TITLE']          = $this->title;
                $pRec['AUTHOR']         = 'mambursoft';
                $pRec['DESCRIPTION_RU'] = $descRu;
                $pRec['DESCRIPTION_EN'] = $descEn;
                $pRec['CURRENT_VERSION']= '1.2.1';
                $pRec['IS_INSTALLED']   = 1;
                SQLUpdate('plugins', $pRec);
            }
        }
    }

    function install($data = '')
    {
        $this->dbInstall();
        parent::install();

        $this->getConfig();
        // Realistic, safe defaults so the module is usable out-of-the-box in
        // observe/shadow. These are typical values for the documented reference
        // installation (Deye SUN-15K-SG05LP3, 3x RW-F10.6, ~3.2 kWp south@40).
        // They are starting points to review, NOT confirmed site parameters.
        // Reserve is intentionally NOT 0. 'armed' still stays blocked until the
        // device profile is verified (see Config::blockingParameters()).
        $defaults = array(
            'CONTROL_MODE'         => 'shadow',   // observe | shadow | armed (never armed by default)
            'TIMEZONE'             => 'Europe/Kyiv',
            'GRID_STEP_MIN'        => 30,
            'MODE'                 => 'reach_full',
            'CHEAP_START_HOUR'     => 23,
            'CHEAP_START_MIN'      => 0,
            'CHEAP_END_HOUR'       => 7,
            'CHEAP_END_MIN'        => 0,
            // Manual correction for systematic PV forecast bias. Providers model
            // clear-sky-ish STC conversion and often over-forecast a specific
            // install (orientation, shading, soiling, module type). 1.0 = no
            // change; 0.5 = halve the forecast. Auto-calibration from measured
            // history can refine this later.
            'PV_SCALE'             => 1.0,
            'RESERVE_SOC_PCT'      => 20,
            'BATTERY_COUNT'        => 3,          // 3x Deye RW-F10.6 (confirm!)
            'BATTERY_CAPACITY_KWH' => 30.0,       // ~3 x ~10 kWh usable (confirm!)
            'MAX_SOC_PCT'          => 100,
            'MIN_SOC_PCT'          => 10,
            'MAX_CHARGE_KW'        => 7.0,         // conservative for a 15K hybrid
            'MAX_DISCHARGE_KW'     => 7.0,
            'ETA_CHARGE'           => 0.95,
            'ETA_DISCHARGE'        => 0.95,
            'TARIFF_CHEAP_PRICE'   => 2.64,       // UA night tariff example (UAH/kWh)
            'TARIFF_DAY_PRICE'     => 4.32,       // UA day tariff example (UAH/kWh)
            'ALLOW_EXPORT'         => 0,
            'SOC_STEP_PCT'         => 5,
            'ENSEMBLE_METHOD'      => 'median',
            'PROFILE_VERIFIED'     => 0,
            'TRANSPORT'            => 'mdm_property',
            'FIRMWARE'             => '',
            'DEYE_HOST'            => '',
            'DEYE_PORT'            => '',
            'DEYE_SERIAL'          => '',
            'LATITUDE'             => '',
            'LONGITUDE'            => '',
            'OPEN_METEO_ENABLED'   => 1,
            'FORECAST_SOLAR_ENABLED' => 0,
            'SOLCAST_ENABLED'      => 0,
            'SOLCAST_API_KEY'      => '',
            'FORECAST_SOLAR_API_KEY' => '',
            'SOLCAST_RESOURCE_IDS' => '',
            'SOLCAST_RESERVED_UNITS' => 2,
            'ANNOUNCE_PLAN'        => 0,
            'DATA_DIR'             => '',
            // Forecast caching / fetch schedule (save provider quota).
            'CACHE_MAX_AGE_MIN'    => 360,   // a cached forecast is usable for 6h
            'FORECAST_SOLAR_MIN_INTERVAL_MIN' => 20, // Forecast.Solar ~12/h per IP
            'SOLCAST_DAY_FETCHES'  => 3,     // daytime Solcast refreshes
            'SOLCAST_NIGHT_FETCHES'=> 4,     // night Solcast refreshes (tomorrow matters)
            // A representative single south-facing array so Open-Meteo returns a
            // plausible PV curve immediately. Replace with real arrays.
            'PV_ARRAYS_JSON'       => '[{"array_id":"roof_south","kwp":3.22,"tilt_deg":40,"azimuth_module_deg":180,"dc_loss":0.14,"temp_coeff_pct_per_c":-0.004}]',
            // Default property map points at SolarPlanner.* mirror properties so
            // telemetry has somewhere to read from until mapped to the real module.
            'PROPERTY_MAP_JSON'    => '{"battery_soc":"SolarPlanner.CurrentSoc","pv_power_kw":"SolarPlanner.PvPower","load_power_kw":"SolarPlanner.LoadPower","grid_power_kw":"SolarPlanner.GridPower","battery_power_kw":"SolarPlanner.BatteryPower"}',
        );
        foreach ($defaults as $k => $v) {
            if (!isset($this->config[$k])) {
                $this->config[$k] = $v;
            }
        }
        $this->saveConfig();
        $this->checkInstalled();
    }

    function dbInstall($data = '')
    {
        // Append-only history tables. Migrations are re-safe (dbInstall only
        // adds missing columns); updating the module must not wipe history.
        $data = <<<EOD
solarplanner_forecast_runs: ID int(10) unsigned NOT NULL auto_increment
solarplanner_forecast_runs: PROVIDER_ID varchar(32) NOT NULL DEFAULT ''
solarplanner_forecast_runs: FORECAST_RUN_ID varchar(96) NOT NULL DEFAULT ''
solarplanner_forecast_runs: RETRIEVED_AT_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_forecast_runs: VALID_FROM_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_forecast_runs: VALID_TO_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_forecast_runs: ENERGY_BASIS varchar(16) NOT NULL DEFAULT ''
solarplanner_forecast_runs: RAW_RESPONSE_HASH varchar(72) NOT NULL DEFAULT ''
solarplanner_forecast_runs: PAYLOAD mediumtext
solarplanner_forecast_runs: CREATED datetime

solarplanner_forecast_intervals: ID int(10) unsigned NOT NULL auto_increment
solarplanner_forecast_intervals: RUN_ID int(10) unsigned NOT NULL DEFAULT '0'
solarplanner_forecast_intervals: INTERVAL_START_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_forecast_intervals: INTERVAL_END_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_forecast_intervals: PV_ENERGY_KWH float NOT NULL DEFAULT '0'
solarplanner_forecast_intervals: IS_MISSING tinyint(1) NOT NULL DEFAULT '0'
solarplanner_forecast_intervals: IS_INTERPOLATED tinyint(1) NOT NULL DEFAULT '0'

solarplanner_telemetry: ID int(10) unsigned NOT NULL auto_increment
solarplanner_telemetry: SAMPLE_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_telemetry: BATTERY_SOC_PCT float
solarplanner_telemetry: PV_POWER_KW float
solarplanner_telemetry: LOAD_POWER_KW float
solarplanner_telemetry: GRID_POWER_KW float
solarplanner_telemetry: BATTERY_POWER_KW float
solarplanner_telemetry: FLAGS varchar(255) NOT NULL DEFAULT ''

solarplanner_planning_runs: ID int(10) unsigned NOT NULL auto_increment
solarplanner_planning_runs: PLAN_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_planning_runs: STATUS varchar(24) NOT NULL DEFAULT ''
solarplanner_planning_runs: TARGET_SOC_AT_07 float
solarplanner_planning_runs: NIGHT_IMPORT_KWH float
solarplanner_planning_runs: DAY_IMPORT_KWH float
solarplanner_planning_runs: PV_TOMORROW_KWH float
solarplanner_planning_runs: PV_TOMORROW_RAW_KWH float
solarplanner_planning_runs: LOAD_TOMORROW_KWH float
solarplanner_planning_runs: TOMORROW_LOCAL_DATE varchar(10) NOT NULL DEFAULT ''
solarplanner_planning_runs: ALGORITHM_VERSION varchar(16) NOT NULL DEFAULT ''
solarplanner_planning_runs: PAYLOAD mediumtext
solarplanner_planning_runs: CREATED datetime

solarplanner_tou_plans: ID int(10) unsigned NOT NULL auto_increment
solarplanner_tou_plans: PLAN_RUN_ID int(10) unsigned NOT NULL DEFAULT '0'
solarplanner_tou_plans: SLOTS_JSON text
solarplanner_tou_plans: COMPILED_OK tinyint(1) NOT NULL DEFAULT '0'
solarplanner_tou_plans: CREATED datetime

solarplanner_command_audit: ID int(10) unsigned NOT NULL auto_increment
solarplanner_command_audit: TS_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_command_audit: EVENT varchar(48) NOT NULL DEFAULT ''
solarplanner_command_audit: DETAIL text

solarplanner_manual_overrides: ID int(10) unsigned NOT NULL auto_increment
solarplanner_manual_overrides: UNTIL_UTC int(11) NOT NULL DEFAULT '0'
solarplanner_manual_overrides: TARGET_SOC float
solarplanner_manual_overrides: NOTE varchar(255) NOT NULL DEFAULT ''
solarplanner_manual_overrides: CREATED datetime

solarplanner_device_profiles: ID int(10) unsigned NOT NULL auto_increment
solarplanner_device_profiles: PROFILE_ID varchar(48) NOT NULL DEFAULT ''
solarplanner_device_profiles: VERIFIED tinyint(1) NOT NULL DEFAULT '0'
solarplanner_device_profiles: PAYLOAD mediumtext
solarplanner_device_profiles: CREATED datetime

solarplanner_calibration: ID int(10) unsigned NOT NULL auto_increment
solarplanner_calibration: PROVIDER_ID varchar(32) NOT NULL DEFAULT ''
solarplanner_calibration: HORIZON varchar(24) NOT NULL DEFAULT ''
solarplanner_calibration: MAE float
solarplanner_calibration: BIAS float
solarplanner_calibration: RMSE float
solarplanner_calibration: MAPE float
solarplanner_calibration: SCALE float
solarplanner_calibration: FORECAST_KWH float
solarplanner_calibration: ACTUAL_KWH float
solarplanner_calibration: DATE_LOCAL varchar(10) NOT NULL DEFAULT ''
solarplanner_calibration: N_SAMPLES int(10) NOT NULL DEFAULT '0'
solarplanner_calibration: UPDATED datetime

solarplanner_quota_state: ID int(10) unsigned NOT NULL auto_increment
solarplanner_quota_state: STATE_KEY varchar(32) NOT NULL DEFAULT 'default'
solarplanner_quota_state: PAYLOAD mediumtext
solarplanner_quota_state: UPDATED datetime
EOD;
        parent::dbInstall($data);
    }

    function uninstall()
    {
        // Preserve history by default; only drop volatile tables. Owners who
        // want a full purge can drop the solarplanner_* tables manually.
        SQLExec("DROP TABLE IF EXISTS solarplanner_tou_plans");
        parent::uninstall();
    }

    /**
     * CSRF token for state-changing admin actions. Falls back to a signed
     * cookie when PHP sessions are unavailable (embedded widgets, AJAX), so a
     * token rendered on one request still validates on the next.
     */
    private function csrfToken()
    {
        $seed = null;
        if (session_status() !== PHP_SESSION_DISABLED) {
            if (session_status() === PHP_SESSION_NONE) {
                @session_start();
            }
            if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['solarplanner_csrf'])) {
                $seed = $_SESSION['solarplanner_csrf'];
            }
        }
        if ($seed === null && isset($_COOKIE['solarplanner_csrf'])
            && preg_match('/^[a-f0-9]{32}$/', $_COOKIE['solarplanner_csrf'])) {
            $seed = $_COOKIE['solarplanner_csrf'];
        }
        if ($seed === null) {
            $seed = bin2hex(random_bytes(16));
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION['solarplanner_csrf'] = $seed;
            }
            if (!headers_sent()) {
                @setcookie('solarplanner_csrf', $seed, 0, '/', '', false, true);
            }
        }
        $sid = session_status() === PHP_SESSION_ACTIVE ? session_id() : '';
        return md5($seed . $this->name . $sid);
    }

    private function csrfValid()
    {
        // POST only: $_REQUEST may include cookies depending on variables_order.
        $token = isset($_POST['sp_csrf']) ? $_POST['sp_csrf']
            : (isset($_GET['sp_csrf']) ? $_GET['sp_csrf'] : null);
        return is_string($token) && hash_equals($this->csrfToken(), $token);
    }

    /**
     * Base URL for links/forms inside the module admin panel.
     *
     * MajorDoMo routes module pages by the panel marker in the query string:
     *   ?(panel:{action=solarplanner})&md=solarplanner&view_mode=...
     * Rebuilding this from REQUEST_URI loses the marker (and sometimes `md`),
     * which sends the user back to the main dashboard. Use the canonical form
     * that the core templates themselves use.
     */
    private function baseUrl()
    {
        $module = $this->name ? $this->name : 'solarplanner';
        return '?(panel:{action=' . $module . '})&md=' . $module . '&';
    }

    function admin(&$out)
    {
        $this->getConfig();
        global $action, $mode;

        $stateChanging = in_array($action, array('save_settings', 'set_mode',
            'create_objects', 'fetch_solcast', 'run_plan', 'run_diagnostics'), true)
            || $mode == 'save_settings';
        if ($stateChanging && !$this->csrfValid()) {
            $out['ERROR'] = 'Недійсний CSRF-токен. Оновіть сторінку та спробуйте ще раз.';
            $action = '';
            $mode = '';
        }

        if ($action == 'save_settings' || $mode == 'save_settings') {
            $this->saveSettings($out);
        }

        if ($action == 'run_plan') {
            $res = $this->triggerPlan();
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($res);
            exit;
        }

        if ($action == 'create_objects') {
            $res = $this->provisionMirrorObject();
            if (isset($_REQUEST['ajax'])) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode($res);
                exit;
            }
            if (!empty($res['success'])) {
                $out['SUCCESS'] = $res['message'];
            } else {
                $out['ERROR'] = isset($res['error']) ? $res['error'] : 'Не вдалося створити обʼєкт.';
            }
            $this->view_mode = 'settings';
        }

        if ($action == 'run_diagnostics') {
            $force = !empty($_REQUEST['force']);
            $res = $this->runDiagnostics($force);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($res);
            exit;
        }

        if ($action == 'fetch_solcast') {
            $res = $this->fetchSolcastResources();
            if (!empty($res['success'])) {
                $out['SUCCESS'] = $res['message'];
            } else {
                $out['ERROR'] = isset($res['error']) ? $res['error'] : 'Не вдалося отримати ресурси Solcast.';
            }
            $this->view_mode = 'settings';
        }

        if ($action == 'list_properties') {
            // AJAX: return properties of a given object for the mapping picker.
            global $object;
            $objName = isset($_REQUEST['object']) ? trim($_REQUEST['object']) : trim($object);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($this->listObjectProperties($objName));
            exit;
        }

        if ($action == 'auto_map_properties') {
            // AJAX: auto-detect a best-guess object.property for each indicator
            // by scanning existing objects/properties by name keywords.
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($this->autoDetectPropertyMap());
            exit;
        }

        if ($action == 'set_mode') {
            global $control_mode;
            $cm = isset($_REQUEST['control_mode']) ? trim($_REQUEST['control_mode']) : trim($control_mode);
            // 'armed' allowed only if configuration unblocks it.
            $allowed = Config::allowedControlMode($this->configToArray());
            if ($cm === 'armed' && $allowed !== 'armed') {
                $out['ERROR'] = 'Режим armed заблоковано: не всі обов\'язкові параметри підтверджені.';
            } else {
                $this->config['CONTROL_MODE'] = in_array($cm, array('observe', 'shadow', 'armed'), true) ? $cm : 'shadow';
                $this->saveConfig();
                $out['SUCCESS'] = 'Режим керування оновлено: ' . $this->config['CONTROL_MODE'];
            }
        }

        $this->populateView($out);
    }

    function usual(&$out)
    {
        $this->admin($out);
    }

    private function saveSettings(&$out)
    {
        $previous = $this->config;
        $map = array(
            'TIMEZONE' => 'timezone', 'GRID_STEP_MIN' => 'grid_step_min', 'MODE' => 'planner_mode',
            'RESERVE_SOC_PCT' => 'reserve_soc_pct', 'BATTERY_COUNT' => 'battery_count',
            'BATTERY_CAPACITY_KWH' => 'battery_capacity_kwh', 'MAX_SOC_PCT' => 'max_soc_pct',
            'MIN_SOC_PCT' => 'min_soc_pct', 'MAX_CHARGE_KW' => 'max_charge_kw',
            'MAX_DISCHARGE_KW' => 'max_discharge_kw', 'ETA_CHARGE' => 'eta_charge',
            'ETA_DISCHARGE' => 'eta_discharge', 'TARIFF_CHEAP_PRICE' => 'tariff_cheap_price',
            'TARIFF_DAY_PRICE' => 'tariff_day_price', 'SOC_STEP_PCT' => 'soc_step_pct',
            'ENSEMBLE_METHOD' => 'ensemble_method', 'TRANSPORT' => 'transport', 'FIRMWARE' => 'firmware',
            'PV_SCALE' => 'pv_scale',
            'LATITUDE' => 'latitude', 'LONGITUDE' => 'longitude',
            'DEYE_HOST' => 'deye_host', 'DEYE_PORT' => 'deye_port',
            'SOLCAST_RESOURCE_IDS' => 'solcast_resource_ids',
        );
        foreach ($map as $cfgKey => $postKey) {
            if (isset($_POST[$postKey])) {
                $this->config[$cfgKey] = trim($_POST[$postKey]);
            }
        }

        // Server-side numeric validation (the browser's min/max is not trusted).
        $ranges = array(
            'RESERVE_SOC_PCT' => array(0, 100), 'MAX_SOC_PCT' => array(1, 100),
            'MIN_SOC_PCT' => array(0, 100), 'SOC_STEP_PCT' => array(1, 100),
            'BATTERY_COUNT' => array(0, 100), 'BATTERY_CAPACITY_KWH' => array(0, 1000),
            'MAX_CHARGE_KW' => array(0, 500), 'MAX_DISCHARGE_KW' => array(0, 500),
            'ETA_CHARGE' => array(0.5, 1), 'ETA_DISCHARGE' => array(0.5, 1),
            'TARIFF_CHEAP_PRICE' => array(0, 100000), 'TARIFF_DAY_PRICE' => array(0, 100000),
            'PV_SCALE' => array(0.1, 2.0), 'GRID_STEP_MIN' => array(15, 60),
        );
        $bad = array();
        foreach ($ranges as $cfgKey => $bounds) {
            if (!isset($this->config[$cfgKey]) || $this->config[$cfgKey] === '') {
                continue;
            }
            $v = $this->config[$cfgKey];
            if (!is_numeric($v)) {
                $bad[] = $cfgKey;
                $this->config[$cfgKey] = isset($previous[$cfgKey]) ? $previous[$cfgKey] : $bounds[0];
                continue;
            }
            $this->config[$cfgKey] = max($bounds[0], min($bounds[1], (float)$v));
        }
        // Explicit logical bounds: reserve cannot exceed the SOC ceiling.
        if ((float)$this->config['MIN_SOC_PCT'] > (float)$this->config['MAX_SOC_PCT']) {
            $bad[] = 'MIN_SOC_PCT';
            $this->config['MIN_SOC_PCT'] = isset($previous['MIN_SOC_PCT']) ? $previous['MIN_SOC_PCT'] : 10;
        }
        if ((float)$this->config['RESERVE_SOC_PCT'] > (float)$this->config['MAX_SOC_PCT']) {
            $bad[] = 'RESERVE_SOC_PCT';
            $this->config['RESERVE_SOC_PCT'] = isset($previous['RESERVE_SOC_PCT']) ? $previous['RESERVE_SOC_PCT'] : 20;
        }
        if (!empty($bad)) {
            $out['ERROR'] = 'Некоректні числові значення: ' . implode(', ', $bad) . '. Відновлено попередні.';
        }

        // PV arrays / property map: these come from JS-built hidden fields. Guard
        // against an accidental wipe — if the posted value is empty or an empty
        // JSON container ([] / {}) but we already have real data stored, keep the
        // existing data instead of clearing it (e.g. saving from another tab, or
        // JS that did not run). An explicit non-empty value always overwrites.
        foreach (array('PV_ARRAYS_JSON' => 'pv_arrays_json', 'PROPERTY_MAP_JSON' => 'property_map_json') as $cfgKey => $postKey) {
            if (!isset($_POST[$postKey])) {
                continue;
            }
            $val = trim($_POST[$postKey]);
            $isEmptyish = ($val === '' || $val === '[]' || $val === '{}' || $val === 'null');
            $existing = isset($this->config[$cfgKey]) ? trim((string)$this->config[$cfgKey]) : '';
            $existingHasData = ($existing !== '' && $existing !== '[]' && $existing !== '{}' && $existing !== 'null');
            if ($isEmptyish && $existingHasData) {
                continue; // keep existing; do not wipe
            }
            $this->config[$cfgKey] = $val;
        }

        // Cheap-tariff window as HH:MM time inputs (supports minutes, e.g.
        // 23:05 / 06:55). Parsed into hour + minute config fields.
        foreach (array('cheap_start' => array('CHEAP_START_HOUR', 'CHEAP_START_MIN'),
                       'cheap_end' => array('CHEAP_END_HOUR', 'CHEAP_END_MIN')) as $postKey => $keys) {
            if (isset($_POST[$postKey]) && preg_match('/^(\d{1,2}):(\d{2})$/', trim($_POST[$postKey]), $m)) {
                $h = max(0, min(23, (int)$m[1]));
                $mn = max(0, min(59, (int)$m[2]));
                $this->config[$keys[0]] = $h;
                $this->config[$keys[1]] = $mn;
            }
        }

        // Secret keys: only overwrite when a new non-masked value is supplied,
        // so re-saving the form with the masked placeholder does not wipe them.
        foreach (array('SOLCAST_API_KEY' => 'solcast_api_key', 'FORECAST_SOLAR_API_KEY' => 'forecast_solar_api_key', 'DEYE_SERIAL' => 'deye_serial') as $cfgKey => $postKey) {
            if (isset($_POST[$postKey])) {
                $val = trim($_POST[$postKey]);
                if ($val !== '' && strpos($val, '*') === false) {
                    $this->config[$cfgKey] = $val;
                }
            }
        }
        // Validate JSON fields; on parse error keep the previous value and warn.
        foreach (array('PV_ARRAYS_JSON', 'PROPERTY_MAP_JSON') as $jsonKey) {
            if (isset($this->config[$jsonKey]) && $this->config[$jsonKey] !== '') {
                $decoded = json_decode($this->config[$jsonKey], true);
                if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                    $out['ERROR'] = 'Некоректний JSON у полі ' . $jsonKey . ' — зміну не збережено.';
                    unset($this->config[$jsonKey]);
                    $this->getConfig(); // reload to drop the bad value
                }
            }
        }
        foreach (array('ALLOW_EXPORT' => 'allow_export', 'OPEN_METEO_ENABLED' => 'open_meteo_enabled',
                     'FORECAST_SOLAR_ENABLED' => 'forecast_solar_enabled', 'SOLCAST_ENABLED' => 'solcast_enabled',
                     'PROFILE_VERIFIED' => 'profile_verified') as $cfgKey => $postKey) {
            // Only change flags that the submitted form actually owns. Saving
            // the Deye/Safety tab must not disable providers or clear
            // PROFILE_VERIFIED. The settings form posts hidden 0 sentinels.
            if (array_key_exists($postKey, $_POST)) {
                $this->config[$cfgKey] = !empty($_POST[$postKey]) ? 1 : 0;
            }
        }
        // Auto-calibration defaults to ON. It is only turned off when the
        // settings form explicitly posts the field unchecked.
        if (array_key_exists('pv_auto_calibrate', $_POST)) {
            $this->config['PV_AUTO_CALIBRATE'] = !empty($_POST['pv_auto_calibrate']) ? 1 : 0;
        } elseif (!isset($this->config['PV_AUTO_CALIBRATE'])) {
            $this->config['PV_AUTO_CALIBRATE'] = 1;
        }
        if (array_key_exists('solcast_shared_externally', $_POST)) {
            $this->config['SOLCAST_SHARED_EXTERNALLY'] = !empty($_POST['solcast_shared_externally']) ? 1 : 0;
        }
        foreach (array('PV_CALIBRATION_ALPHA' => 'pv_calibration_alpha',
                       'SOLCAST_DAILY_LIMIT_UNITS' => 'solcast_daily_limit_units',
                       'SOLCAST_RESERVED_UNITS' => 'solcast_reserved_units',
                       'CACHE_HORIZON_SLACK_MIN' => 'cache_horizon_slack_min',
                       'CURTAILMENT_PENALTY_PER_KWH' => 'curtailment_penalty_per_kwh') as $cfgKey => $postKey) {
            if (isset($_POST[$postKey]) && is_numeric($_POST[$postKey])) {
                $this->config[$cfgKey] = max(0, (float)$_POST[$postKey]);
            }
        }
        if (isset($_POST['controllable_hourly_kw_json'])) {
            $decoded = json_decode(trim($_POST['controllable_hourly_kw_json']), true);
            if (is_array($decoded) && count($decoded) === 24) {
                $this->config['CONTROLLABLE_HOURLY_KW_JSON'] = json_encode(array_values($decoded));
            }
        }
        $this->saveConfig();
        setGlobal('cycle_solarplannerControl', 'restart');
        if (empty($out['ERROR'])) {
            $out['SUCCESS'] = 'Налаштування збережено. Сигнал перезапуску циклу відправлено.';
        }
        $this->view_mode = 'settings';
    }

    private function configToArray()
    {
        $c = $this->config;
        return array(
            'battery_count' => isset($c['BATTERY_COUNT']) ? (int)$c['BATTERY_COUNT'] : 0,
            'battery_capacity_kwh' => isset($c['BATTERY_CAPACITY_KWH']) ? (float)$c['BATTERY_CAPACITY_KWH'] : 0,
            'reserve_soc_pct' => isset($c['RESERVE_SOC_PCT']) ? (float)$c['RESERVE_SOC_PCT'] : 0,
            'tariff_cheap_price' => isset($c['TARIFF_CHEAP_PRICE']) ? $c['TARIFF_CHEAP_PRICE'] : '',
            'tariff_day_price' => isset($c['TARIFF_DAY_PRICE']) ? $c['TARIFF_DAY_PRICE'] : '',
            'transport' => isset($c['TRANSPORT']) ? $c['TRANSPORT'] : '',
            'firmware' => isset($c['FIRMWARE']) ? $c['FIRMWARE'] : '',
            'property_map' => !empty($c['PROPERTY_MAP_JSON']) ? $c['PROPERTY_MAP_JSON'] : '',
            'pv_arrays' => $this->loadPvArrays(),
            'profile_verified' => isset($c['PROFILE_VERIFIED']) ? (int)$c['PROFILE_VERIFIED'] : 0,
        );
    }

    private function loadPvArrays()
    {
        // PV arrays live in private config JSON; empty by default.
        if (!empty($this->config['PV_ARRAYS_JSON'])) {
            $a = json_decode($this->config['PV_ARRAYS_JSON'], true);
            return is_array($a) ? $a : array();
        }
        return array();
    }

    /**
     * Create the MajorDoMo "SolarPlanner" mirror object with the telemetry
     * properties the planner reads (CurrentSoc, PvPower, LoadPower, GridPower,
     * BatteryPower) plus the published plan properties. Idempotent.
     *
     * This gives a non-specialist owner a one-click way to get valid objects to
     * map against, without hand-writing JSON or creating objects manually.
     */
    function provisionMirrorObject()
    {
        $className = 'SolarPlanner';
        $objName = 'SolarPlanner';

        $classRec = SQLSelectOne("SELECT ID FROM classes WHERE TITLE='" . DBSafe($className) . "'");
        if (!$classRec['ID']) {
            $classRec = array('TITLE' => $className, 'DESCRIPTION' => 'Планувальник сонячної енергії');
            $classRec['ID'] = SQLInsert('classes', $classRec);
        }

        $objRec = SQLSelectOne("SELECT ID FROM objects WHERE TITLE='" . DBSafe($objName) . "'");
        if (!$objRec['ID']) {
            $objRec = array('TITLE' => $objName, 'CLASS_ID' => $classRec['ID'], 'DESCRIPTION' => 'Solar Planner mirror');
            $objRec['ID'] = SQLInsert('objects', $objRec);
        }

        if (!function_exists('getObject')) {
            return array('success' => false, 'error' => 'getObject() недоступний у цьому середовищі.');
        }
        $obj = getObject($objName);
        if (!$obj) {
            return array('success' => false, 'error' => 'Не вдалося отримати обʼєкт ' . $objName);
        }

        // Telemetry mirror props (owner / another module fills these) + planner
        // outputs (the planner writes these).
        $props = array(
            'CurrentSoc' => '', 'PvPower' => '', 'LoadPower' => '', 'GridPower' => '', 'BatteryPower' => '',
            'Enabled' => '1', 'ControlMode' => 'shadow', 'Status' => 'observe',
            'TargetSocAt07' => '', 'PlannedGridChargeKwh' => '', 'PlannedNightImportKwh' => '',
            'ExpectedDayImportKwh' => '', 'ForecastPvTomorrowKwh' => '', 'ForecastLoadTomorrowKwh' => '',
            'ForecastPvTomorrowLowKwh' => '', 'ForecastPvTomorrowHighKwh' => '',
            'ForecastPvTomorrowRawKwh' => '', 'ForecastQuality' => '', 'CalibrationScale' => '',
            'ExpectedCurtailmentKwh' => '', 'ExpectedFullAt' => '',
            'ExpectedSocAtHorizonEnd' => '', 'PlanExplanation' => '',
        );
        $created = 0;
        foreach ($props as $pName => $pDef) {
            $cur = $obj->getProperty($pName);
            if ($cur === false || $cur === null) {
                $obj->setProperty($pName, $pDef);
                $created++;
            }
        }

        return array(
            'success' => true,
            'message' => 'Обʼєкт "SolarPlanner" готовий (' . $created . ' нових властивостей). Тепер у мапінгу можна вибрати SolarPlanner.* або натиснути «Використати дзеркальні обʼєкти».',
            'object' => $objName,
        );
    }

    /**
     * Build a full diagnostic report (environment self-check + per-provider
     * forecast attempt) without necessarily saving a plan. Used by the
     * Diagnostics tab and its "Re-check" button.
     */
    function runDiagnostics($force = false)
    {
        $this->getConfig();
        require_once(dirname(__FILE__) . '/lib/MajorDoMo/DiagnosticsService.php');
        require_once(dirname(__FILE__) . '/lib/MajorDoMo/SqlForecastStore.php');
        $cfg = is_array($this->config) ? $this->config : array();
        $diag = new \SolarPlanner\MajorDoMo\DiagnosticsService($cfg, $this->forecastCache(), $this->propGetter());
        $now = time();
        $store = new \SolarPlanner\MajorDoMo\SqlForecastStore();
        try {
            $collected = $diag->collect($now, $now + 44 * 3600, $store, $force);
        } catch (\Throwable $e) {
            return array('ok' => false, 'error' => $e->getMessage());
        }
        $usable = 0;
        foreach ($collected['providers'] as $p) {
            if ($p['status'] === 'fresh' || $p['status'] === 'partial') {
                $usable++;
            }
        }
        return array(
            'ok' => true,
            'usable_providers' => $usable,
            'providers' => $collected['providers'],
            'environment' => $collected['env'],
            'site' => $collected['site'],
        );
    }

    /**
     * Fetch the owner's Solcast rooftop resources using the saved API key and
     * auto-fill SOLCAST_RESOURCE_IDS, so the owner never has to find/paste the
     * resource id by hand. Nothing is printed except counts (no key leakage).
     */
    function fetchSolcastResources()
    {
        $this->getConfig();
        $key = isset($this->config['SOLCAST_API_KEY']) ? trim($this->config['SOLCAST_API_KEY']) : '';
        if ($key === '') {
            return array('success' => false, 'error' => 'Спочатку збережіть Solcast API key у налаштуваннях.');
        }
        require_once(dirname(__FILE__) . '/lib/Forecast/HttpClient.php');
        $http = new \SolarPlanner\Forecast\HttpClient(15, 1, false);
        $url = 'https://api.solcast.com.au/rooftop_sites?format=json';
        $guard = $http->guardUrl($url);
        if ($guard !== true) {
            return array('success' => false, 'error' => 'SSRF-захист: ' . $guard);
        }
        $res = $http->get($url, array('Authorization' => 'Bearer ' . $key, 'Accept' => 'application/json'));
        if ($res['status'] === 401 || $res['status'] === 403) {
            return array('success' => false, 'error' => 'Solcast відхилив ключ (HTTP ' . $res['status'] . '). Перевірте API key.');
        }
        if ($res['status'] !== 200) {
            return array('success' => false, 'error' => 'Solcast повернув HTTP ' . $res['status'] . '.');
        }
        $data = json_decode($res['body'], true);
        if (!isset($data['sites']) || !is_array($data['sites']) || empty($data['sites'])) {
            return array('success' => false, 'error' => 'За цим ключем не знайдено жодного rooftop site.');
        }
        $ids = array();
        $names = array();
        foreach ($data['sites'] as $s) {
            if (!empty($s['resource_id'])) {
                $ids[] = $s['resource_id'];
                $names[] = isset($s['name']) ? $s['name'] : $s['resource_id'];
            }
        }
        if (empty($ids)) {
            return array('success' => false, 'error' => 'Відповідь без resource_id.');
        }
        $this->config['SOLCAST_RESOURCE_IDS'] = implode(',', $ids);
        $this->config['SOLCAST_ENABLED'] = 1;
        $this->saveConfig();
        setGlobal('cycle_solarplannerControl', 'restart');
        return array(
            'success' => true,
            'message' => 'Знайдено ' . count($ids) . ' resource_id (' . htmlspecialchars(implode(', ', $names)) . '). Solcast увімкнено.',
        );
    }

    /**
     * A ForecastCache backed by MajorDoMo's `settings` table (durable KV), so
     * plan recomputes reuse the last forecast and do not spend provider quota.
     */
    public function forecastCache()
    {
        require_once(dirname(__FILE__) . '/lib/Forecast/ForecastCache.php');
        $maxAge = isset($this->config['CACHE_MAX_AGE_MIN']) ? (int)$this->config['CACHE_MAX_AGE_MIN'] * 60 : 6 * 3600;
        return new \SolarPlanner\Forecast\ForecastCache(
            function ($key) { return self::kvGet($key); },
            function ($key, $val) { self::kvSet($key, $val); },
            $maxAge
        );
    }

    /** Getter for MajorDoMo object properties (gg wrapper) for SolarWindows. */
    public function propGetter()
    {
        return function ($prop) {
            return function_exists('gg') ? gg($prop) : null;
        };
    }

    /** Durable KV read from the `settings` table (NAME/VALUE). */
    public static function kvGet($key)
    {
        if (!SQLSelectOne("SHOW TABLES LIKE 'settings'")) {
            return null;
        }
        $row = SQLSelectOne("SELECT VALUE FROM settings WHERE NAME='" . DBSafe($key) . "'");
        return ($row && isset($row['VALUE'])) ? $row['VALUE'] : null;
    }

    /** Durable KV write to the `settings` table (NAME/VALUE). */
    public static function kvSet($key, $value)
    {
        if (!SQLSelectOne("SHOW TABLES LIKE 'settings'")) {
            return;
        }
        $row = SQLSelectOne("SELECT ID FROM settings WHERE NAME='" . DBSafe($key) . "'");
        // Note: SQLInsert() takes the record BY REFERENCE, so the array must be
        // a variable (PHP 7.3 fatals on passing a literal by reference).
        if ($row && isset($row['ID'])) {
            $rec = array('ID' => $row['ID'], 'NAME' => $key, 'VALUE' => $value);
            SQLUpdate('settings', $rec);
        } else {
            $rec = array('NAME' => $key, 'VALUE' => $value);
            SQLInsert('settings', $rec);
        }
    }

    /** List MajorDoMo objects (TITLE) for the picker dropdowns. */
    private function listObjects()
    {
        $rows = SQLSelect("SELECT TITLE FROM objects ORDER BY TITLE ASC");
        $out = array();
        if (is_array($rows)) {
            foreach ($rows as $r) {
                if (!empty($r['TITLE'])) {
                    $out[] = $r['TITLE'];
                }
            }
        }
        return $out;
    }

    /**
     * Has the user done the minimum setup needed for the overview to be useful?
     * True when coordinates and at least one PV array are set and the property
     * map links a battery SOC source (or the profile is explicitly verified).
     * Used to decide whether a fresh install opens on Settings vs Overview.
     */
    private function isConfigured()
    {
        $c = is_array($this->config) ? $this->config : array();
        if (!empty($c['PROFILE_VERIFIED'])) {
            return true;
        }
        $hasCoords = isset($c['LATITUDE']) && $c['LATITUDE'] !== '' && isset($c['LONGITUDE']) && $c['LONGITUDE'] !== '';
        $hasArrays = false;
        if (!empty($c['PV_ARRAYS_JSON'])) {
            $a = json_decode($c['PV_ARRAYS_JSON'], true);
            $hasArrays = is_array($a) && count($a) > 0;
        }
        $hasSoc = false;
        if (!empty($c['PROPERTY_MAP_JSON'])) {
            $pm = json_decode($c['PROPERTY_MAP_JSON'], true);
            $hasSoc = is_array($pm) && !empty($pm['battery_soc']);
        }
        return $hasCoords && $hasArrays && $hasSoc;
    }

    /** AJAX helper: list property names of one object for the mapping picker. */
    private function listObjectProperties($objName)
    {
        if ($objName === '') {
            return array();
        }
        $objRec = SQLSelectOne("SELECT ID, CLASS_ID FROM objects WHERE TITLE='" . DBSafe($objName) . "'");
        if (!$objRec || !$objRec['ID']) {
            return array();
        }
        return $this->objectAllProperties((int)$objRec['ID'], (int)(isset($objRec['CLASS_ID']) ? $objRec['CLASS_ID'] : 0));
    }

    /**
     * All property names available on an object: its own (OBJECT_ID) PLUS the
     * ones it inherits from its class chain (CLASS_ID, following PARENT_ID).
     * MajorDoMo defines most properties at the class level, so querying only
     * OBJECT_ID misses inherited properties — which is why the picker showed an
     * incomplete list. Returns a de-duplicated, sorted list of titles.
     */
    private function objectAllProperties($objectId, $classId)
    {
        $names = array();

        // Own (instance-level) properties.
        if ($objectId > 0) {
            $rows = SQLSelect("SELECT TITLE FROM properties WHERE OBJECT_ID=" . (int)$objectId);
            foreach (($rows ?: array()) as $r) {
                if (!empty($r['TITLE'])) { $names[$r['TITLE']] = true; }
            }
        }

        // Inherited class properties, walking the class parent chain.
        $cid = (int)$classId;
        $seen = array();
        while ($cid > 0 && !isset($seen[$cid])) {
            $seen[$cid] = true;
            $rows = SQLSelect("SELECT TITLE FROM properties WHERE CLASS_ID=" . $cid
                . " AND (OBJECT_ID=0 OR OBJECT_ID IS NULL)");
            foreach (($rows ?: array()) as $r) {
                if (!empty($r['TITLE'])) { $names[$r['TITLE']] = true; }
            }
            $cl = SQLSelectOne("SELECT PARENT_ID FROM classes WHERE ID=" . $cid);
            $cid = $cl ? (int)$cl['PARENT_ID'] : 0;
        }

        $out = array_keys($names);
        sort($out, SORT_STRING | SORT_FLAG_CASE);
        return $out;
    }

    /**
     * Auto-detect a best-guess property map by scanning all objects' properties
     * for name keywords typical of an inverter/BMS integration. Only confident,
     * unambiguous matches are filled; everything else stays null so the user
     * confirms. If the SolarPlanner mirror object exists, its known properties
     * are used as a strong fallback for the core telemetry fields.
     *
     * @return array ['map'=>[field=>'Object.Property'|null], 'message'=>string]
     */
    private function autoDetectPropertyMap()
    {
        // Keyword patterns per indicator (lowercased, matched against
        // "object.property"). Order matters: earlier = stronger preference.
        $patterns = array(
            'battery_soc'          => array('soc', 'stateofcharge', 'charge_level', 'batterylevel'),
            'soc_updated_utc'      => array('soc_updated', 'soc_time', 'soc_ts'),
            'pv_power_kw'          => array('pv_power', 'pvpower', 'solarpower', 'pv_kw', 'ppv', 'pv1power'),
            'load_power_kw'        => array('load_power', 'loadpower', 'consumption', 'house_power', 'pload'),
            'grid_power_kw'        => array('grid_power', 'gridpower', 'meter_power', 'pgrid'),
            'battery_power_kw'     => array('battery_power', 'batterypower', 'batt_power', 'pbattery', 'pbat'),
            'grid_connected'       => array('grid_connected', 'ongrid', 'grid_on', 'mains'),
            'inverter_alarm'       => array('alarm', 'fault', 'error', 'warning'),
            'bms_charge_limit_a'   => array('charge_limit', 'chargecurrentlimit', 'maxchargecurrent', 'cclimit'),
            'bms_discharge_limit_a'=> array('discharge_limit', 'dischargecurrentlimit', 'maxdischargecurrent', 'dclimit'),
            'grid_charge_enabled'  => array('grid_charge', 'gridcharge', 'ac_charge', 'charge_from_grid'),
            'tou_schedule_json'    => array('tou', 'time_of_use', 'schedule'),
        );

        // Build a flat list of "Object.Property" candidates once, covering BOTH
        // instance-level properties and properties inherited from the object's
        // class (class-level properties have OBJECT_ID=0, so an OBJECT_ID-only
        // join would miss them).
        $pairs = array(); // lowercased "obj.prop" => "Obj.Prop" (original case)

        // (1) Instance-level properties.
        $rows = SQLSelect(
            "SELECT o.TITLE AS otitle, p.TITLE AS ptitle " .
            "FROM properties p INNER JOIN objects o ON o.ID = p.OBJECT_ID " .
            "WHERE p.TITLE != '' AND o.TITLE != ''"
        );
        foreach (($rows ?: array()) as $r) {
            $full = $r['otitle'] . '.' . $r['ptitle'];
            $pairs[strtolower($full)] = $full;
        }

        // (2) Class-level (inherited) properties: attach each class property to
        // every object of that class. Parent-class inheritance is resolved by
        // objectAllProperties for the per-object picker; for auto-detect a
        // single level covers the common inverter/BMS case well.
        $rows = SQLSelect(
            "SELECT o.TITLE AS otitle, p.TITLE AS ptitle " .
            "FROM properties p INNER JOIN objects o ON o.CLASS_ID = p.CLASS_ID " .
            "WHERE p.TITLE != '' AND o.TITLE != '' AND p.CLASS_ID > 0 " .
            "AND (p.OBJECT_ID = 0 OR p.OBJECT_ID IS NULL)"
        );
        foreach (($rows ?: array()) as $r) {
            $full = $r['otitle'] . '.' . $r['ptitle'];
            $pairs[strtolower($full)] = $full;
        }

        $mirrorFallback = array(
            'battery_soc'      => 'SolarPlanner.CurrentSoc',
            'pv_power_kw'      => 'SolarPlanner.PvPower',
            'load_power_kw'    => 'SolarPlanner.LoadPower',
            'grid_power_kw'    => 'SolarPlanner.GridPower',
            'battery_power_kw' => 'SolarPlanner.BatteryPower',
        );
        $mirrorExists = (bool)SQLSelectOne("SELECT ID FROM objects WHERE TITLE='SolarPlanner'");

        $map = array();
        $matched = 0;
        foreach ($patterns as $field => $keywords) {
            $best = null;
            foreach ($keywords as $kw) {
                foreach ($pairs as $lc => $orig) {
                    // Prefer a match on the property part, and skip our own mirror
                    // object so auto-detect finds the REAL inverter objects first.
                    if (strpos($lc, 'solarplanner.') === 0) {
                        continue;
                    }
                    if (strpos($lc, $kw) !== false) {
                        $best = $orig;
                        break 2;
                    }
                }
            }
            if ($best === null && $mirrorExists && isset($mirrorFallback[$field])) {
                $best = $mirrorFallback[$field];
            }
            if ($best !== null) {
                $matched++;
            }
            $map[$field] = $best; // null when nothing confident found
        }

        $msg = $matched > 0
            ? 'Автоматично визначено відповідностей: ' . $matched . '. Перевірте та збережіть.'
            : 'Не знайдено придатних об\'єктів. Створіть дзеркальні об\'єкти або оберіть вручну.';
        return array('map' => $map, 'message' => $msg, 'matched' => $matched);
    }

    /**
     * Localized, plain-language dictionary of every control/safety state for a
     * non-specialist homeowner. Text comes from the language files via LANG_*
     * constants, with safe fallbacks if a key is missing.
     *
     * Returns: code => ['name'=>..., 'desc'=>..., 'badge'=>bootstrap label class]
     */
    private function stateDictionary()
    {
        $L = function ($const, $fallback) {
            return defined($const) ? constant($const) : $fallback;
        };
        return array(
            'observe' => array(
                'name' => $L('LANG_SP_STATE_OBSERVE', 'Спостереження'),
                'desc' => $L('LANG_SP_STATE_OBSERVE_D', 'Модуль лише дивиться: читає дані лічильника й батареї, нічого не рахує для керування і нічого не змінює в інверторі. Найбезпечніший режим для першого знайомства.'),
                'badge' => 'label-default',
            ),
            'shadow' => array(
                'name' => $L('LANG_SP_STATE_SHADOW', 'Тіньовий режим'),
                'desc' => $L('LANG_SP_STATE_SHADOW_D', 'Модуль розраховує повний план (скільки докупити вночі, цільовий заряд на 07:00) і показує його вам, але НЕ надсилає жодних команд інвертору. Так можна тижнями перевіряти якість порад без ризику. Це режим за замовчуванням.'),
                'badge' => 'label-info',
            ),
            'approval_required' => array(
                'name' => $L('LANG_SP_STATE_APPROVAL', 'Потрібне підтвердження'),
                'desc' => $L('LANG_SP_STATE_APPROVAL_D', 'План готовий до застосування, але чекає вашого дозволу. Нічого не запишеться, доки ви вручну не підтвердите саме цей план.'),
                'badge' => 'label-warning',
            ),
            'armed' => array(
                'name' => $L('LANG_SP_STATE_ARMED', 'Активне керування'),
                'desc' => $L('LANG_SP_STATE_ARMED_D', 'Модулю дозволено записувати розклад Time of Use в інвертор — але лише після низки перевірок безпеки і з підтвердженим профілем пристрою. Вмикайте, коли переконались у плані в тіньовому режимі.'),
                'badge' => 'label-danger',
            ),
            'applying' => array(
                'name' => $L('LANG_SP_STATE_APPLYING', 'Застосування'),
                'desc' => $L('LANG_SP_STATE_APPLYING_D', 'Прямо зараз модуль записує новий розклад в інвертор. Короткочасний технічний стан.'),
                'badge' => 'label-primary',
            ),
            'verifying' => array(
                'name' => $L('LANG_SP_STATE_VERIFYING', 'Перевірка запису'),
                'desc' => $L('LANG_SP_STATE_VERIFYING_D', 'Модуль зчитує з інвертора те, що щойно записав, і звіряє з очікуваним. Успіхом вважається лише збіг, а не просто відсутність помилки звʼязку.'),
                'badge' => 'label-primary',
            ),
            'active' => array(
                'name' => $L('LANG_SP_STATE_ACTIVE', 'Працює'),
                'desc' => $L('LANG_SP_STATE_ACTIVE_D', 'Розклад успішно записано й підтверджено зчитуванням. Інвертор працює за планом модуля.'),
                'badge' => 'label-success',
            ),
            'degraded' => array(
                'name' => $L('LANG_SP_STATE_DEGRADED', 'Обмежена робота'),
                'desc' => $L('LANG_SP_STATE_DEGRADED_D', 'Щось пішло не так: застарілі дані, розбіжність після запису або недоступний провайдер. Модуль працює обережно й не виконує ризикованих записів, доки ситуація не виправиться.'),
                'badge' => 'label-warning',
            ),
            'blocked' => array(
                'name' => $L('LANG_SP_STATE_BLOCKED', 'Заблоковано'),
                'desc' => $L('LANG_SP_STATE_BLOCKED_D', 'Запис заборонено через безпеку: тривога BMS чи інвертора, неперевірений профіль пристрою або заборонене поле. Керування не відбуватиметься, доки причину не усунуто.'),
                'badge' => 'label-danger',
            ),
            'manual_override' => array(
                'name' => $L('LANG_SP_STATE_MANUAL', 'Ручне керування'),
                'desc' => $L('LANG_SP_STATE_MANUAL_D', 'Ви (або інший контролер) керуєте інвертором вручну. Модуль це поважає і не перезаписує ваші налаштування, доки ручний режим не завершиться.'),
                'badge' => 'label-default',
            ),
        );
    }

    /**
     * Run a planning pass synchronously, right now, so the UI can show the real
     * result (or the specific reason it failed) immediately — not just a flag
     * for the background cycle. Also nudges the cycle for the next scheduled run.
     */
    private function triggerPlan()
    {
        $this->getConfig();
        require_once(dirname(__FILE__) . '/lib/MajorDoMo/SqlForecastStore.php');
        require_once(dirname(__FILE__) . '/lib/MajorDoMo/DiagnosticsService.php');
        require_once(dirname(__FILE__) . '/lib/MajorDoMo/PlanRunner.php');

        $cfg = is_array($this->config) ? $this->config : array();
        require_once(dirname(__FILE__) . '/lib/Forecast/ForecastCache.php');
        $store = new \SolarPlanner\MajorDoMo\SqlForecastStore();
        $self = $this;

        try {
            $plan = \SolarPlanner\MajorDoMo\PlanRunner::run($cfg, $store, array(
                'cache' => $this->forecastCache(),
                'prop_getter' => $this->propGetter(),
                'force_fetch' => true, // manual "Run plan" => refresh now
                'get_soc' => function () {
                    // Only trust a plausible, recent SOC reading. A literal 0 or
                    // a very old sample usually means the inverter/BMS link is
                    // not wired yet (mirror objects still empty). In that case
                    // return null so PlanRunner starts from a safe default
                    // (reserve) instead of planning from 0% — which would make
                    // every candidate breach the reserve and look "infeasible".
                    $row = SQLSelectOne("SELECT BATTERY_SOC_PCT, SAMPLE_UTC FROM solarplanner_telemetry WHERE BATTERY_SOC_PCT IS NOT NULL ORDER BY SAMPLE_UTC DESC LIMIT 1");
                    if (!$row || $row['BATTERY_SOC_PCT'] === null) {
                        return null;
                    }
                    $soc = (float)$row['BATTERY_SOC_PCT'];
                    $age = isset($row['SAMPLE_UTC']) ? (time() - (int)$row['SAMPLE_UTC']) : PHP_INT_MAX;
                    // Reject: non-positive (no link), impossible (>100), or stale (>6h).
                    if ($soc <= 0.0 || $soc > 100.0 || $age > 6 * 3600) {
                        return null;
                    }
                    return $soc;
                },
                'get_history' => function () {
                    $since = time() - 336 * 3600;
                    $rows = SQLSelect("SELECT SAMPLE_UTC, LOAD_POWER_KW FROM solarplanner_telemetry WHERE SAMPLE_UTC >= $since AND LOAD_POWER_KW IS NOT NULL ORDER BY SAMPLE_UTC ASC");
                    $h = array();
                    if (is_array($rows)) {
                        foreach ($rows as $r) {
                            $h[] = array('utc' => (int)$r['SAMPLE_UTC'], 'load_kw' => (float)$r['LOAD_POWER_KW'], 'valid' => true);
                        }
                    }
                    return $h;
                },
                'publish' => function ($plan, $cfg) use ($self) {
                    $self->publishPlanProperties($plan, $cfg);
                },
            ));
        } catch (\Throwable $e) {
            return array('success' => false, 'message' => 'Помилка розрахунку: ' . $e->getMessage());
        }

        setGlobal('cycle_solarplannerControl', 'plan_now');

        $status = isset($plan['status']) ? $plan['status'] : 'unknown';
        if ($status === 'feasible') {
            $msg = 'План розраховано. TargetSocAt07 = ' . (isset($plan['target_soc_at_07']) ? $plan['target_soc_at_07'] : '?') . '%.';
        } elseif ($status === 'no_forecast') {
            $msg = 'Прогноз недоступний. Причина: ' . (isset($plan['reason']) ? $plan['reason'] : 'невідомо') . ' Деталі — на вкладці «Діагностика».';
        } elseif ($status === 'infeasible') {
            $msg = 'План нездійсненний за поточних обмежень. Деталі — на вкладці «План».';
        } else {
            $msg = 'Статус плану: ' . $status . '. Деталі — на вкладці «Діагностика».';
        }
        return array('success' => true, 'status' => $status, 'message' => $msg);
    }

    /**
     * Publish plan results to the SolarPlanner.* MajorDoMo properties (used by
     * the inline run; mirrors the cycle's publisher).
     */
    public function publishPlanProperties($plan, $cfg)
    {
        $set = function ($prop, $val) { setGlobal($prop, $val); };
        $set('SolarPlanner.Enabled', 1);
        $set('SolarPlanner.ControlMode', isset($cfg['CONTROL_MODE']) ? $cfg['CONTROL_MODE'] : 'shadow');
        $set('SolarPlanner.Status', isset($plan['status']) ? $plan['status'] : 'unknown');
        $set('SolarPlanner.LastPlanAt', date('Y-m-d H:i:s'));
        $map = array(
            'target_soc_at_07' => 'SolarPlanner.TargetSocAt07',
            'planned_grid_charge_kwh' => 'SolarPlanner.PlannedGridChargeKwh',
            'planned_night_import_kwh' => 'SolarPlanner.PlannedNightImportKwh',
            'expected_day_import_kwh' => 'SolarPlanner.ExpectedDayImportKwh',
            'pv_tomorrow_kwh' => 'SolarPlanner.ForecastPvTomorrowKwh',
            'pv_tomorrow_low_kwh' => 'SolarPlanner.ForecastPvTomorrowLowKwh',
            'pv_tomorrow_high_kwh' => 'SolarPlanner.ForecastPvTomorrowHighKwh',
            'load_tomorrow_kwh' => 'SolarPlanner.ForecastLoadTomorrowKwh',
            'pv_tomorrow_raw_kwh' => 'SolarPlanner.ForecastPvTomorrowRawKwh',
            'forecast_quality' => 'SolarPlanner.ForecastQuality',
            'expected_curtailment_kwh' => 'SolarPlanner.ExpectedCurtailmentKwh',
            'expected_soc_at_horizon_end' => 'SolarPlanner.ExpectedSocAtHorizonEnd',
        );
        if (isset($plan['expected_full_at_utc']) && $plan['expected_full_at_utc'] !== null) {
            $set('SolarPlanner.ExpectedFullAt', date('Y-m-d H:i', (int)$plan['expected_full_at_utc']));
        }
        if (isset($plan['calibration']['scale'])) {
            $set('SolarPlanner.CalibrationScale', $plan['calibration']['scale']);
        }
        foreach ($map as $k => $prop) {
            if (isset($plan[$k])) {
                $set($prop, $plan[$k]);
            }
        }
        // On an infeasible plan there is no target_soc_at_07; publishing nothing
        // leaves the property at a misleading 0%. Instead publish the suggested
        // safe compromise so the homeowner sees an actionable number, and mark
        // that it is a suggestion (not an executed target).
        if ((!isset($plan['target_soc_at_07']) || $plan['target_soc_at_07'] === null)
            && isset($plan['suggested_safe_compromise_soc']) && $plan['suggested_safe_compromise_soc'] !== null) {
            $set('SolarPlanner.TargetSocAt07', $plan['suggested_safe_compromise_soc']);
            $set('SolarPlanner.TargetSocIsSuggestion', 1);
        } else {
            $set('SolarPlanner.TargetSocIsSuggestion', 0);
        }
        if (isset($plan['explanation_obj']['text'])) {
            $set('SolarPlanner.PlanExplanation', $plan['explanation_obj']['text']);
        }
    }

    private function populateView(&$out)
    {
        $cfgArr = $this->configToArray();
        $blocking = Config::blockingParameters($cfgArr);
        $allowed = Config::allowedControlMode($cfgArr);

        $vm = $this->view_mode;
        if (isset($_GET['view_mode'])) {
            $vm = $_GET['view_mode'];
        }
        if (!$vm) {
            // No tab requested: open the Overview by default, but send a
            // not-yet-configured install straight to Settings so the user is
            // not greeted by an empty overview and extra clicks.
            $vm = $this->isConfigured() ? 'overview' : 'settings';
        }
        $out['VIEW_MODE'] = $vm;

        $controlMode = isset($this->config['CONTROL_MODE']) ? $this->config['CONTROL_MODE'] : 'shadow';
        $out['CONTROL_MODE']   = $controlMode;
        $out['ALLOWED_MODE']   = $allowed;
        $out['ARMED_BLOCKED']  = ($allowed !== 'armed') ? 1 : 0;

        // Friendly localized label + plain-language description for the states.
        $states = $this->stateDictionary();
        $out['CONTROL_MODE_LABEL'] = isset($states[$controlMode]) ? $states[$controlMode]['name'] : $controlMode;
        $out['CONTROL_MODE_DESC']  = isset($states[$controlMode]) ? $states[$controlMode]['desc'] : '';
        $out['ALLOWED_MODE_LABEL'] = isset($states[$allowed]) ? $states[$allowed]['name'] : $allowed;

        // Full reference table for the Safety tab. Precompute row class and the
        // "current" marker so the template needs no conditionals inside the loop.
        $nowWord = defined('LANG_SP_STATES_NOW') ? LANG_SP_STATES_NOW : 'current';
        $stateRows = array();
        foreach ($states as $code => $info) {
            $isCurrent = ($code === $controlMode);
            $stateRows[] = array(
                'CODE' => $code,
                'NAME' => htmlspecialchars($info['name']),
                'DESC' => htmlspecialchars($info['desc']),
                'BADGE' => $info['badge'],
                'ROWCLASS' => $isCurrent ? 'success' : '',
                'NOWMARK' => $isCurrent ? '<small class="text-success">&larr; ' . htmlspecialchars($nowWord) . '</small>' : '',
            );
        }
        $out['STATES'] = $stateRows;

        // Defaults for settings introduced in 1.2.1 so their fields always
        // render with a meaningful value on upgraded installs.
        foreach (array(
            'PV_AUTO_CALIBRATE' => 1, 'PV_CALIBRATION_ALPHA' => 0.25,
            'SOLCAST_DAILY_LIMIT_UNITS' => 0, 'SOLCAST_RESERVED_UNITS' => 2,
            'CACHE_HORIZON_SLACK_MIN' => 360, 'CURTAILMENT_PENALTY_PER_KWH' => 0.05,
        ) as $defKey => $defVal) {
            if (!isset($this->config[$defKey])) {
                $this->config[$defKey] = $defVal;
            }
        }
        // Settings for the form. API keys are shown masked (never echo the real
        // key); coordinates ARE shown to the owner in their own protected
        // settings form (they are only kept out of Git/logs/snapshots).
        foreach ($this->config as $k => $v) {
            $out['CFG_' . $k] = is_scalar($v) ? htmlspecialchars((string)$v) : '';
        }
        $out['CFG_SOLCAST_API_KEY'] = !empty($this->config['SOLCAST_API_KEY']) ? '********' : '';
        $out['CFG_FORECAST_SOLAR_API_KEY'] = !empty($this->config['FORECAST_SOLAR_API_KEY']) ? '********' : '';
        $out['CFG_DEYE_SERIAL'] = !empty($this->config['DEYE_SERIAL']) ? '********' : '';

        // Cheap-tariff window as HH:MM for the time inputs (minutes supported).
        $csh = isset($this->config['CHEAP_START_HOUR']) ? (int)$this->config['CHEAP_START_HOUR'] : 23;
        $csm = isset($this->config['CHEAP_START_MIN']) ? (int)$this->config['CHEAP_START_MIN'] : 0;
        $ceh = isset($this->config['CHEAP_END_HOUR']) ? (int)$this->config['CHEAP_END_HOUR'] : 7;
        $cem = isset($this->config['CHEAP_END_MIN']) ? (int)$this->config['CHEAP_END_MIN'] : 0;
        $out['CFG_CHEAP_START'] = sprintf('%02d:%02d', $csh, $csm);
        $out['CFG_CHEAP_END'] = sprintf('%02d:%02d', $ceh, $cem);

        // JSON fields injected into hidden input value="..." attributes must be
        // entity-encoded (incl. quotes) so embedded " does not terminate the
        // attribute. ENT_QUOTES encodes both ' and ". JS overwrites these on
        // change; the pre-fill prevents a save from wiping arrays/map when the
        // user did not touch those widgets.
        $pvJson = isset($this->config['PV_ARRAYS_JSON']) ? (string)$this->config['PV_ARRAYS_JSON'] : '';
        $pmJson = isset($this->config['PROPERTY_MAP_JSON']) ? (string)$this->config['PROPERTY_MAP_JSON'] : '';
        $out['CFG_PV_ARRAYS_JSON_ATTR'] = htmlspecialchars($pvJson, ENT_QUOTES);
        $out['CFG_PROPERTY_MAP_JSON_ATTR'] = htmlspecialchars($pmJson, ENT_QUOTES);

        // Localized labels for the Planner-mode and Ensemble-method dropdowns.
        // Injected as [#VAR#] (reliably substituted) instead of <#LANG#> inside
        // <option>, which the panel's language pass does not resolve.
        $L = function ($const, $fallback) {
            return defined($const) ? constant($const) : $fallback;
        };
        $out['LBL_MODE_REACH_FULL'] = $L('LANG_SP_MODE_REACH_FULL', 'reach_full');
        $out['LBL_MODE_MIN_COST']   = $L('LANG_SP_MODE_MIN_COST', 'minimum_cost');
        $out['LBL_ENS_MEDIAN']      = $L('LANG_SP_ENS_MEDIAN', 'median');
        $out['LBL_ENS_MEAN']        = $L('LANG_SP_ENS_MEAN', 'mean');
        $out['LBL_ENS_WEIGHTED']    = $L('LANG_SP_ENS_WEIGHTED', 'weighted');
        $out['LBL_ENS_BEST']        = $L('LANG_SP_ENS_BEST', 'best');

        // Routing-safe base URL and CSRF token for every state-changing form.
        $out['SP_BASE_URL'] = $this->baseUrl();
        $out['SP_CSRF'] = $this->csrfToken();
        $jsonFlags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;

        // Transport: expose a simple flag so the template can hide the Deye
        // network fields when everything goes through MajorDoMo properties.
        $out['TRANSPORT_IS_MDM'] = (isset($this->config['TRANSPORT']) && $this->config['TRANSPORT'] === 'mdm_property') ? 1 : 0;

        // Blocking parameters list for the UI.
        $blkList = array();
        foreach ($blocking as $key => $label) {
            $blkList[] = array('KEY' => $key, 'LABEL' => htmlspecialchars($label));
        }
        $out['BLOCKING_PARAMS'] = $blkList;
        $out['HAS_BLOCKING'] = empty($blkList) ? 0 : 1;

        // Objects list for the property-map picker (as a JS array).
        $out['OBJECTS_JSON'] = json_encode($this->listObjects(), $jsonFlags);

        // Current PV arrays (decoded) for the friendly builder, as JS data.
        $pvArrays = $this->loadPvArrays();
        $out['PV_ARRAYS_DATA_JSON'] = json_encode(array_values($pvArrays), $jsonFlags);

        // Current property map (decoded) for the picker, as JS data.
        $pmRaw = isset($this->config['PROPERTY_MAP_JSON']) ? $this->config['PROPERTY_MAP_JSON'] : '';
        $pm = $pmRaw ? json_decode($pmRaw, true) : array();
        $out['PROPERTY_MAP_DATA_JSON'] = json_encode(is_array($pm) ? $pm : array(), $jsonFlags);

        // Whether the SolarPlanner mirror object exists already.
        $mirror = SQLSelectOne("SELECT ID FROM objects WHERE TITLE='SolarPlanner'");
        $out['MIRROR_EXISTS'] = ($mirror && $mirror['ID']) ? 1 : 0;

        // Last planning run.
        if (SQLSelectOne("SHOW TABLES LIKE 'solarplanner_planning_runs'")) {
            $last = SQLSelectOne("SELECT * FROM solarplanner_planning_runs ORDER BY ID DESC LIMIT 1");
            if ($last && $last['ID']) {
                $out['LAST_PLAN_STATUS']      = htmlspecialchars($last['STATUS']);
                $statusMap = array(
                    'feasible' => array('LANG_SP_STATUS_FEASIBLE', 'Здійсненний', 'label-success'),
                    'infeasible' => array('LANG_SP_STATUS_INFEASIBLE', 'Нездійсненний', 'label-danger'),
                    'no_forecast' => array('LANG_SP_STATUS_NO_FORECAST', 'Немає прогнозу', 'label-warning'),
                    'error' => array('LANG_SP_STATUS_ERROR', 'Помилка', 'label-danger'),
                );
                $st = isset($statusMap[$last['STATUS']]) ? $statusMap[$last['STATUS']]
                    : array(null, (string)$last['STATUS'], 'label-default');
                $out['LAST_PLAN_STATUS_LABEL'] = htmlspecialchars($L($st[0], $st[1]));
                $out['LAST_PLAN_STATUS_CLASS'] = $st[2];
                $out['LAST_PLAN_TARGET_SOC']  = round((float)$last['TARGET_SOC_AT_07'], 1);
                $out['LAST_PLAN_NIGHT_KWH']   = round((float)$last['NIGHT_IMPORT_KWH'], 2);
                $out['LAST_PLAN_DAY_KWH']     = round((float)$last['DAY_IMPORT_KWH'], 2);
                $out['LAST_PLAN_PV_KWH']      = round((float)$last['PV_TOMORROW_KWH'], 2);
                $out['LAST_PLAN_LOAD_KWH']    = round((float)$last['LOAD_TOMORROW_KWH'], 2);
                $out['LAST_PLAN_AT']          = date('Y-m-d H:i', (int)$last['PLAN_UTC']);
                $payload = json_decode($last['PAYLOAD'], true);
                // PV forecast context: which local day, and a plausibility flag
                // when modelled per-kWp yield is physically implausible.
                $out['LAST_PLAN_PV_DATE'] = isset($payload['tomorrow_local_date']) ? htmlspecialchars($payload['tomorrow_local_date']) : '';
                $out['LAST_PLAN_PV_HORIZON_KWH'] = isset($payload['pv_horizon_kwh']) ? round((float)$payload['pv_horizon_kwh'], 2) : '';
                $out['LAST_PLAN_PV_DAYAFTER_KWH'] = isset($payload['pv_day_after_kwh']) ? round((float)$payload['pv_day_after_kwh'], 2) : '';
                $out['LAST_PLAN_PV_IMPLAUSIBLE'] = !empty($payload['pv_forecast_implausible']) ? 1 : 0;
                $out['LAST_PLAN_PV_PER_KWP'] = isset($payload['pv_tomorrow_kwh_per_kwp']) && $payload['pv_tomorrow_kwh_per_kwp'] !== null
                    ? round((float)$payload['pv_tomorrow_kwh_per_kwp'], 2) : '';
                $out['LAST_PLAN_PV_TODAY_KWH'] = isset($payload['pv_today_remaining_kwh'])
                    ? round((float)$payload['pv_today_remaining_kwh'], 2) : '';
                $out['LAST_PLAN_PV_SUSPECT'] = !empty($payload['pv_forecast_suspect']) ? 1 : 0;
                $out['LAST_PLAN_FORECAST_QUALITY'] = isset($payload['forecast_quality'])
                    ? htmlspecialchars((string)$payload['forecast_quality']) : '';
                $cal = isset($payload['calibration']) && is_array($payload['calibration'])
                    ? $payload['calibration'] : array();
                $out['LAST_PLAN_CALIB_MAE']   = isset($cal['mae']) && $cal['mae'] !== null ? round((float)$cal['mae'], 2) : '—';
                $out['LAST_PLAN_CALIB_BIAS']  = isset($cal['bias']) && $cal['bias'] !== null ? round((float)$cal['bias'], 2) : '—';
                $out['LAST_PLAN_CALIB_N']     = isset($cal['n']) ? (int)$cal['n'] : 0;
                $out['LAST_PLAN_CALIB_SCALE'] = isset($cal['scale']) ? round((float)$cal['scale'], 3) : '1.000';
                $out['LAST_PLAN_CALIB_DATE']  = isset($cal['date_local']) ? htmlspecialchars($cal['date_local']) : '—';
                // Render the explanation as safe HTML: each line as its own
                // paragraph/list item so it is readable, not one run-on blob.
                $lines = array();
                if (isset($payload['explanation_obj']['lines']) && is_array($payload['explanation_obj']['lines'])) {
                    $lines = $payload['explanation_obj']['lines'];
                } elseif (isset($payload['explanation_obj']['text'])) {
                    $lines = preg_split('/\r?\n/', (string)$payload['explanation_obj']['text']);
                }
                $html = '';
                foreach ($lines as $ln) {
                    $ln = trim((string)$ln);
                    if ($ln === '') { continue; }
                    $html .= '<div class="sp-expl-line">' . htmlspecialchars($ln) . '</div>';
                }
                $out['LAST_PLAN_EXPLANATION'] = $html !== '' ? $html : '—';
                // Plain text (for the property mirror / tooltips).
                $out['LAST_PLAN_EXPLANATION_TEXT'] = isset($payload['explanation_obj']['text'])
                    ? htmlspecialchars($payload['explanation_obj']['text']) : '';
                // Is the shown target a suggestion (infeasible) or an executed plan?
                $out['LAST_PLAN_TARGET_IS_SUGGESTION'] =
                    (!isset($payload['target_soc_at_07']) || $payload['target_soc_at_07'] === null)
                    && isset($payload['suggested_safe_compromise_soc']) ? 1 : 0;
                if ($out['LAST_PLAN_TARGET_IS_SUGGESTION'] && isset($payload['suggested_safe_compromise_soc'])) {
                    $out['LAST_PLAN_TARGET_SOC'] = round((float)$payload['suggested_safe_compromise_soc'], 1);
                }
            }
        }

        // Forecast-vs-actual series for the overview chart. Only verified days
        // (stored by the calibration loop) are shown.
        $series = array();
        if (SQLSelectOne("SHOW TABLES LIKE 'solarplanner_calibration'")) {
            $rows = SQLSelect("SELECT DATE_LOCAL, FORECAST_KWH, ACTUAL_KWH FROM solarplanner_calibration "
                . "WHERE PROVIDER_ID='ensemble' AND FORECAST_KWH IS NOT NULL AND ACTUAL_KWH IS NOT NULL "
                . "ORDER BY ID DESC LIMIT 14");
            foreach (array_reverse($rows) as $r) {
                $series[] = array(
                    'date' => isset($r['DATE_LOCAL']) ? $r['DATE_LOCAL'] : '',
                    'forecast' => round((float)$r['FORECAST_KWH'], 2),
                    'actual' => round((float)$r['ACTUAL_KWH'], 2),
                );
            }
        }
        $out['PV_ACCURACY_JSON'] = json_encode($series, $jsonFlags);

        // Current telemetry mirror (from MajorDoMo properties, if mapped).
        // These values come from MajorDoMo properties (which may be fed by
        // MQTT/HTTP integrations): HTML-escape before handing to the template.
        $out['SP_SOC']  = htmlspecialchars((string)gg('SolarPlanner.CurrentSoc'), ENT_QUOTES, 'UTF-8');
        $out['SP_PV']   = htmlspecialchars((string)gg('SolarPlanner.PvPower'), ENT_QUOTES, 'UTF-8');
        $out['SP_LOAD'] = htmlspecialchars((string)gg('SolarPlanner.LoadPower'), ENT_QUOTES, 'UTF-8');

        // Cycle liveness.
        $cycleRun = (int)gg('cycle_solarplannerRun');
        $out['CYCLE_ALIVE'] = (time() - $cycleRun) < 120 ? 1 : 0;
        $out['CYCLE_TIME']  = $cycleRun > 0 ? date('Y-m-d H:i:s', $cycleRun) : 'Ніколи';

        // Diagnostics tab: run the self-check and flatten it for the template.
        if ($vm === 'diagnostics') {
            $this->populateDiagnostics($out);
        }
    }

    /** Flatten the diagnostic report into template-friendly rows. */
    private function populateDiagnostics(&$out)
    {
        // A forced refresh issues outbound HTTP and writes forecast/quota rows,
        // so it needs the same CSRF token as other state-changing actions.
        $force = !empty($_GET['force']) && $this->csrfValid();
        $rep = $this->runDiagnostics($force);
        if (empty($rep['ok'])) {
            $out['DIAG_ERROR'] = htmlspecialchars(isset($rep['error']) ? $rep['error'] : 'unknown');
            return;
        }
        $env = $rep['environment'];

        // Environment checks as a list of [label, ok(1/0), value].
        $checks = array(
            array('Конфігурацію завантажено', $env['config_loaded'], $env['config_keys'] . ' ключів'),
            array('Увімкнено провайдер(и)', $env['any_provider_enabled'], $env['any_provider_enabled'] ? 'так' : 'ні'),
            array('Координати задано', $env['coordinates_set'], $env['coordinates_source']),
            array('PV-масиви задано', $env['pv_arrays_set'], $env['pv_arrays_set'] ? 'config' : 'заглушка'),
            array('Вихідний HTTPS', $env['outbound_https'], $env['outbound_https_detail']),
            array('cURL доступний', $env['curl_available'], $env['curl_available'] ? 'так' : 'ні (fallback streams)'),
            array('OpenSSL доступний', $env['openssl_available'], $env['openssl_available'] ? 'так' : 'ні'),
            array('Device profile перевірено', $env['profile_verified'], $env['profile_verified'] ? 'так' : 'ні (armed заблоковано)'),
        );
        $rows = array();
        foreach ($checks as $c) {
            $rows[] = array(
                'LABEL' => htmlspecialchars($c[0]),
                'OK' => $c[1] ? 1 : 0,
                'BADGE' => $c[1] ? 'label-success' : 'label-warning',
                'MARK' => $c[1] ? 'OK' : 'УВАГА',
                'VALUE' => htmlspecialchars((string)$c[2]),
            );
        }
        $out['DIAG_CHECKS'] = $rows;

        // Provider rows.
        $prov = array();
        $labels = array('open_meteo' => 'Open-Meteo', 'forecast_solar' => 'Forecast.Solar', 'solcast' => 'Solcast');
        $tz = !empty($this->config['TIMEZONE']) ? $this->config['TIMEZONE'] : 'Europe/Kyiv';
        foreach ($rep['providers'] as $code => $p) {
            $ok = in_array($p['status'], array('fresh', 'partial', 'cached'), true);
            $badge = $ok ? ($p['status'] === 'cached' ? 'label-info' : 'label-success')
                : ($p['status'] === 'disabled' ? 'label-default' : 'label-danger');
            $src = isset($p['source']) ? $p['source'] : '';
            $next = '';
            if (!empty($p['next_fetch_utc'])) {
                try {
                    $next = (new DateTime('@' . (int)$p['next_fetch_utc']))->setTimezone(new DateTimeZone($tz))->format('H:i');
                } catch (\Exception $e) {
                    $next = '';
                }
            }
            $prov[] = array(
                'NAME' => isset($labels[$code]) ? $labels[$code] : $code,
                'CODE' => $code,
                'STATUS' => htmlspecialchars($p['status']),
                'BADGE' => $badge,
                'DETAIL' => htmlspecialchars($p['detail']),
                'TOTAL' => ($p['total_kwh'] === null ? '—' : $p['total_kwh'] . ' кВт·год'),
                'INTERVALS' => (int)$p['intervals'],
                'SOURCE' => htmlspecialchars($src),
                'NEXT' => htmlspecialchars($next),
            );
        }
        $out['DIAG_PROVIDERS'] = $prov;
        $out['DIAG_USABLE'] = (int)$rep['usable_providers'];

        // Sun / schedule summary line.
        if (isset($rep['environment']['sun'])) {
            $sun = $rep['environment']['sun'];
            $fmt = function ($utc) use ($tz) {
                try {
                    return (new DateTime('@' . (int)$utc))->setTimezone(new DateTimeZone($tz))->format('H:i');
                } catch (\Exception $e) {
                    return '?';
                }
            };
            $dark = '';
            if (isset($sun['is_dark']) && $sun['is_dark'] !== null) {
                $dark = ' · зараз ' . ($sun['is_dark'] ? 'темно' : 'світло')
                    . ' (DarknessMode.active)';
            }
            $out['DIAG_SUN'] = 'Світанок ' . $fmt($sun['sunrise_utc']) . ', захід ' . $fmt($sun['sunset_utc'])
                . ' · дешеве вікно ' . $fmt($sun['night_start_utc']) . '–' . $fmt($sun['night_end_utc'])
                . ' · критичне уточнення до ' . $fmt($sun['critical_refine_utc'])
                . ' · джерело: ' . ($sun['sun_source'] === 'properties' ? 'ThisComputer.SunRise/SunSet' : 'оцінка')
                . $dark;
        }
    }
}
